import React, { useState } from 'react';
import './app.css';
import { Route, BrowserRouter as Router, Routes, Link } from 'react-router-dom';
// import Misc from
// import 
import Landing from  './pages/Landing';


function App() {
return (
    <Router>
        <div className="wrapper" id="main">
        {/* Header Compilation */}
          {/* { header() } */}
        {/* Header End */}
        {/* Content Start */}
        <div id="Heart">
          <div className='container'>
                <nav>
                  <ul>
                    <li>
                      <Link to="/">Home</Link>
                    </li>
                    <li>
                      <Link to="/Landing">Landing</Link>
                    </li>
                  </ul>
                </nav>
              </div>
            <Routes>
              <Route path="/" element={null}/>
              <Route path="/Landing" element={<Landing />} />
              {/* <Route path="/Landing" element={<Boards Board={TempData} />}></Route> */}
            </Routes>
        </div>
        {/* Content End */}
        {/* TaskBar Start Skipped */}
        {/* <div className="TaskBarStyle">
            <div id="TaskBar" className="d-flex">
        </div>
            
        </div>*/}
        {/* TaskBar End */}
        {/* Footer Start */}
          <footer>
            <label id="Footer-MessajeInformation">Listo</label>
          </footer>
        {/* Footer End */}
        </div>
    </Router>
  )
}

export default App;
