import React from 'react'

export default function Landing() {
  return (
    <div>
      Landing
    </div>
  )
}
